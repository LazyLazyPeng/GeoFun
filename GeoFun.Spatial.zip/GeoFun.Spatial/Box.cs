﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GeoFun.Spatial
{
    public struct Box
    {
        public double Xmin;
        public double Ymin;
        public double Xmax;
        public double Ymax;
    }
}
